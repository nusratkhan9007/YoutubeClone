export const API_KEY = 'AIzaSyADLL6QKvtHzSkkemAZc-1fSWZfB9a-CdM';

export const value_converter = (value)=>{
    if(value>=1000000){
        return Math.floor(value/1000000)+"M";
    }
    else if(value>=1000)
    {
        return Math.floor(value/1000)+"K";

    }
    else{
        return value;
    }
}